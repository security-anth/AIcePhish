function analyze(mail_body){
    connect_and_send("Text:"+mail_body)
}